<?php
/**
 * Template part for displaying page content one
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Appilo
 */

?>
    <section class="blog-list blog-style-two">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">

                    <?php the_content();?>

                </div>
            </div>
        </div>
    </section>