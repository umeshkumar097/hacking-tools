<?php
/**
 * Template part for displaying page content 13
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Appilo
 */

 the_content();
 ?>