<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Appilo
 */
get_header();


appilo_dynamic_template('template-parts/404-layouts/404-layout');

get_footer();