<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Appilo
 */

get_header();


appilo_dynamic_template('template-parts/archive-layouts/archive-layout');

get_footer();