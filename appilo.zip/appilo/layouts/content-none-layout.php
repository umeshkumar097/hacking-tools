<?php
/**
 *
 * Content None Layouts
 *
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Appilo
 */

appilo_dynamic_template('template-parts/content-none-layouts/content-none-layout');