<?php

appilo_dynamic_template('template-parts/single-post-layouts/single-post-layout');