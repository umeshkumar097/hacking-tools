<?php
/**
 *
 * Search Layouts
 *
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Appilo
 */

appilo_dynamic_template('template-parts/content-search-layouts/content-search-layout');