<?php

/**
 *
 * Content Layouts
 *
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Appilo
 */


appilo_dynamic_template('template-parts/content-layouts/content-layout');