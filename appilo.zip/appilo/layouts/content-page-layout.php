<?php
/**
 * The template for displaying the content layout
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Appilo
 */


appilo_dynamic_template('template-parts/content-page-layouts/content-page');