<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Appilo
 */

get_header();

appilo_dynamic_template('layouts/search-layouts/search-layout');

get_footer();